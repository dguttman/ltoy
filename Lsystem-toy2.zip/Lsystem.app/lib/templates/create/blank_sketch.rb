# Lsystem

class  < Processing::App

  def setup
    
  end
  
  def draw
  
  end
  
end

.new :title => "Lsystem"